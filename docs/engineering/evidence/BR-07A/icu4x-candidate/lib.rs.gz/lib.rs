use icu_collator::{CollatorBorrowed, options::CollatorOptions};
use icu_locale_core::locale;
use std::sync::OnceLock;
static COLLATOR: OnceLock<CollatorBorrowed<'static>> = OnceLock::new();
#[no_mangle]
pub extern "C" fn alloc(len: usize) -> *mut u16 {
    let buf = vec![0u16;len].into_boxed_slice();
    Box::into_raw(buf) as *mut u16
}
#[no_mangle]
pub unsafe extern "C" fn free(ptr: *mut u16, len: usize) {
    drop(Box::from_raw(std::ptr::slice_from_raw_parts_mut(ptr,len)));
}
#[no_mangle]
pub unsafe extern "C" fn key(input: *const u16,len: usize,output: *mut u16,capacity: usize) -> usize {
    let collator=COLLATOR.get_or_init(||CollatorBorrowed::try_new(locale!("en-US").into(),CollatorOptions::default()).unwrap());
    let mut bytes=Vec::new();
    collator.write_sort_key_utf16_to(std::slice::from_raw_parts(input,len), &mut bytes).unwrap();
    if bytes.len() > capacity { return bytes.len(); }
    for (i,b) in bytes.iter().enumerate() {*output.add(i)=*b as u16;}
    bytes.len()
}
