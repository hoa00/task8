import module from '../support/icu4x-probe.wasm';
interface EncoderExports extends WebAssembly.Exports {
  memory: WebAssembly.Memory;
  alloc: (length: number) => number;
  free: (pointer: number, length: number) => void;
  key: (input: number, length: number, output: number, capacity: number) => number;
}
function exportsOf(instance: WebAssembly.Instance): EncoderExports {
 const value=instance.exports;
 if (!(value.memory instanceof WebAssembly.Memory)||typeof value.alloc!=='function'||typeof value.free!=='function'||typeof value.key!=='function') throw new Error('Invalid encoder ABI');
 return value as EncoderExports;
}
const wasm=exportsOf(new WebAssembly.Instance(module));
function key(s:string):string{
 const input=wasm.alloc(s.length), capacity=s.length*32+128, output=wasm.alloc(capacity);
 try {let memory=new Uint16Array(wasm.memory.buffer);for(let i=0;i<s.length;i++) memory[input/2+i]=s.charCodeAt(i);
 const length=wasm.key(input,s.length,output,capacity);if(length>capacity)throw new Error('Insufficient output');
 memory=new Uint16Array(wasm.memory.buffer);return Array.from(memory.slice(output/2,output/2+length), x=>x.toString(16).padStart(2,'0')).join('');
 }finally{wasm.free(input,s.length);wasm.free(output,capacity);}
}
export default {async fetch(request:Request):Promise<Response>{
 const corpus: string[]=await request.json();
 const rows=corpus.map(s=>({s,key:key(s)}));const sorted=[...rows].sort((a,b)=>a.key<b.key?-1:a.key>b.key?1:0);
 const failures=[];
 for(let i=1;i<sorted.length;i++){const a=sorted[i-1],b=sorted[i];if(!a||!b)throw new Error('Missing row');const actual=Math.sign(a.s.localeCompare(b.s)),expected=a.key<b.key?-1:a.key>b.key?1:0;if(actual!==expected)failures.push({a:a.s,b:b.s,actual,expected});}
 return Response.json({locale:new Intl.Collator().resolvedOptions(),count:rows.length,failures:failures.slice(0,50),failureCount:failures.length});
}};
