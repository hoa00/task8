CREATE INDEX `activity_visible_history` ON `activity` (`workspaceId`,`revertedAt`,`createdAt`,`id`);--> statement-breakpoint
CREATE INDEX `comments_visible_history` ON `comments` (`workspaceId`,`taskId`,`deletedAt`,`createdAt`,`id`);--> statement-breakpoint
CREATE INDEX `files_page_name` ON `files` (`workspaceId`,`projectId`,`deletedAt`,`json_extract("readKeys"`,`'$.name.locale')`,`id`);--> statement-breakpoint
CREATE INDEX `files_page_type` ON `files` (`workspaceId`,`projectId`,`deletedAt`,`json_extract("readKeys"`,`'$.fileType.locale')`,`id`);--> statement-breakpoint
CREATE INDEX `files_page_recent` ON `files` (`workspaceId`,`projectId`,`deletedAt`,(-"createdAt"),`id`);--> statement-breakpoint
CREATE INDEX `files_page_size` ON `files` (`workspaceId`,`projectId`,`deletedAt`,`(-coalesce("sizeBytes"`,`-1))`,`id`);--> statement-breakpoint
CREATE INDEX `notifications_recipient_history` ON `notifications` (`workspaceId`,`recipientId`,`createdAt`,`id`);--> statement-breakpoint
CREATE INDEX `projects_catalog_name` ON `projects` (`workspaceId`,`deletedAt`,`(coalesce("archivedAt"`,`0)!=0)`,`json_extract("readKeys"`,`'$.name.locale')`,`id`);--> statement-breakpoint
CREATE INDEX `tasks_active_manual` ON `tasks` (`workspaceId`,`deletedAt`,`archivedAt`,`position`,`id`);--> statement-breakpoint
CREATE INDEX `tasks_active_title` ON `tasks` (`workspaceId`,`deletedAt`,`archivedAt`,`json_extract("readKeys"`,`'$.title.foldedUtf16')`,`id`);